

use std::io::{BufReader,BufWriter, BufRead,Read}; 
use printpdf::*;
use std::fs::File;
 
use web_sys::window;
use web_sys::Element;
use web_sys::Blob;
use web_sys::Url;
use web_sys::BlobPropertyBag;
use web_sys::Storage;
use wasm_bindgen::prelude::*;
use wasm_bindgen::JsValue;
use std::io::Cursor;
 
use js_sys::*;

use data_url::{DataUrl};
 
fn data_url_to_bytes(data_url: &str) -> Result<Vec<u8>, &'static str> {
    // 尝试从提供的字符串创建一个DataUrl实例
    let data_url = DataUrl::process(data_url).map_err(|_| "Invalid DataURL format")?;
 
    // 确认数据部分的MIME类型是否为PNG图片
    
    if data_url.mime_type().type_!= "image" {
        return Err("Not a PNG image");
    }
 let (body, fragment) = data_url.decode_to_vec().unwrap();
    // 返回Base64解码后的数据
    Ok( body) 
     }
#[wasm_bindgen]
extern "C" {
    fn alert(s: &str);
}
 
#[wasm_bindgen]
pub fn greet(name: &str)  {
 
let (doc, page1, layer1) = PdfDocument::new("PDF_Document_title", Mm(247.0), Mm(210.0), "Layer 1");
let (page2, layer1) = doc.add_page(Mm(200.0), Mm(250.0),"Page 2, Layer 1");
let  pdf_bytes= doc.save_to_bytes().unwrap();
 
  let jsv=JsValue::from(pdf_bytes);
  let s:Vec<JsValue>=vec![jsv];
  let jsv1=JsValue::from(s);
 
  let tye=BlobPropertyBag::new();
    tye.set_type("application/pdf");
   let blob=Blob::new_with_u8_array_sequence_and_options( &jsv1,&tye).unwrap();
    
    let curl=Url::create_object_url_with_blob(&blob).unwrap(); 

   // alert(&format!("Hello, {}!", curl));
 
}
#[wasm_bindgen]
 pub fn start_pdf() {
     start_app();
    }
 fn start_app( ) {
    let document = window()
        .and_then(|win| win.document())
        .expect("Could not access document");
    let body = document.body().expect("Could not access document.body");
    let winw=   window().unwrap();
    let iStorage= winw.local_storage().unwrap().unwrap();
       

    iStorage.set_item("wjcme","tgemptst");
    let geti=iStorage.get_item("imageDataURL").unwrap().unwrap() ;
    let getfn=iStorage.get_item("pdfname").unwrap().unwrap() ;

    let v= data_url_to_bytes(&geti).unwrap();

     let reader = BufReader::new(&v[..]);
let img2 = Image::try_from( image_crate::codecs::jpeg::JpegDecoder::new(reader).unwrap()).unwrap();
//let image=RawImage::decode_from_bytes(v).unwrap(); 
    let wid= Px((img2.image.width.0 as f32 / 2.0) as usize);
   //以一张A4大小的纸张为例，满页打印范围约为20×27.5cm ，以300dpi的解析度打印的话，换算成像素约为2362×3248， 


  
    let mut wid:Mm=Mm(210.0);
    let mut het:Mm=Mm(297.0);
 let mut scalex:f32= 2362.0 as f32/img2.image.width.0  as f32;
    let  mut scaley:f32= 3248.0 as f32/img2.image.height.0  as f32;
    
    
    if  img2.image.height<img2.image.width {

        wid= Mm(297.0);
        het=Mm(210.0);
        scalex= 2362.0 as f32/img2.image.height.0  as f32;
        scaley= 3248.0 as f32/img2.image.width.0  as f32;

    }
          let (doc, page1, layer1) = PdfDocument::new("PDF_Document_title",  wid,het, "Layer 1");
  let current_layer = doc.get_page(page1).get_layer(layer1);
    
    let scale = f32::min(scaley,scalex);
   // alert(&format!("{}",scale));
   img2.add_to_layer(current_layer.clone(), 
    ImageTransform {
      
       scale_x:  Some( scale),
        scale_y:   Some( scale ),
        translate_x: Some(Mm(8.0)),
        translate_y: Some(Mm(8.0)),
        ..Default::default()
    },
);
   
  //  let text_node = document.create_text_node( &format!("Hello, world from Vanilla Rust!{}", &v[..].len()));
  
   let pdf_bytes = doc.save_to_bytes().unwrap();
  let jsv=JsValue::from(pdf_bytes);
  let s:Vec<JsValue>=vec![jsv];
  let jsv1=JsValue::from(s);
  let tye=BlobPropertyBag::new();
    tye.set_type("application/pdf");
   let blob=Blob::new_with_u8_array_sequence_and_options(&jsv1,&tye).unwrap();
//let blob=Blob::new_with_u8_array_sequence(&jsv).unwrap();
    let curl=Url::create_object_url_with_blob(&blob).unwrap(); 
      let  theiframe :Element = document.get_element_by_id("framemain").unwrap();
    theiframe.set_inner_html(&format!("<iframe src='{}' alt='me.pdf' width='1100px' height='600px'></iframe>",curl ));
   let  thedown :Element = document.get_element_by_id("download").unwrap();
   thedown.set_inner_html(&format!("<a href='{}' download='{}.pdf'>本地保存</a>",curl,getfn));
  // let ifm= theiframe.dyn_into::<HtmlIFrameElement>().unwrap().clone();
    //ifm.set_src="d";
 //   body.append_child(text_node.as_ref())
   //     .expect("Failed to append text");
   body.append_child(theiframe.as_ref())
        .expect("Failed to append text");

}

 fn main() {
    console_error_panic_hook::set_once();

  
        let (doc, page1, layer1) = PdfDocument::new("PDF_Document_title", Mm(247.0), Mm(210.0), "Layer 1");
let (page2, layer1) = doc.add_page(Mm(20.0), Mm(250.0),"Page 2, Layer 1");
let pdf_bytes = doc.save_to_bytes().unwrap();

 // doc.save(&mut BufWriter::new(File::create("/tmp/test_working.pdf").unwrap())).unwrap();   
 
   start_app( ) ;
 
}