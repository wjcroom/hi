use printpdf::*;
 
use web_sys::window;
 
use web_sys::Blob;
use web_sys::Url;
use web_sys::BlobPropertyBag;
 
use wasm_bindgen::prelude::*;
use wasm_bindgen::JsValue;
 
use js_sys::*;

use data_url::{DataUrl};
 
fn data_url_to_bytes(data_url: &str) -> Result<Vec<u8>, &'static str> {
    // 尝试从提供的字符串创建一个DataUrl实例
    let data_url = DataUrl::process(data_url).map_err(|_| "Invalid DataURL format")?;
 
    // 确认数据部分的MIME类型是否为PNG图片
    
    if data_url.mime_type().type_!= "image" {
        return Err("Not a PNG image");
    }
 let (body, _fragment) = data_url.decode_to_vec().unwrap();
    // 返回Base64解码后的数据
    Ok( body) 
     }
#[wasm_bindgen]
extern "C" {
    fn alert(s: &str);
}
 
#[wasm_bindgen]
pub fn png2pdf( ) ->String  {
 
 start_app()
  
   // alert(&format!("Hello, {}!", curl));
  
}
#[wasm_bindgen]
 pub fn start_pdf() {
     start_app();
    }
 fn start_app( ) ->String{

          let winw=   window().unwrap();
    let i_storage= winw.local_storage().unwrap().unwrap();
       

     let geti=i_storage.get_item("imageDataURL").unwrap().unwrap() ;
     let v= data_url_to_bytes(&geti).unwrap();
     let mut doc = PdfDocument::new("My first PDF");
   
    let image = RawImage::decode_from_bytes(&v).unwrap(); // requires --feature bmp

    // In the PDF, an image is an `XObject`, identified by a unique `ImageId`
    let (scale,wid,hei) = if image.width <image.height{
          let scalex:f32= 2362.0/image.width as f32;  
        let scaley:f32= 3248.0/ image.height as f32;
        (f32::min(scalex,scaley),Mm(210.0),Mm(297.0))
       
    } else{

      let scalex:f32=  3248.0/image.width as f32;
      let scaley:f32= 2362.0/image.height as f32;
      (f32::min(scalex,scaley),Mm(297.0),Mm(210.0))
    };

   
    let image_xobject_id = doc.add_image(&image);
   
   

    let page1_contents = vec![Op::UseXObject {
        id: image_xobject_id.clone(),
        transform: XObjectTransform{
          scale_x:  Some( scale),
         scale_y:   Some( scale ),
         translate_x:Some(Pt(28.0)),
         translate_y:Some(Pt(28.0)),
        //  rotate : Some(XObjectRotation{
        //    angle_ccw_degrees: rotal,
        //     rotation_center_x: Px((image.width as u32/2.0 as u32) as usize),
        //    rotation_center_y: Px((image.height as u32/2.0 as u32) as usize),
        //  }),
          ..Default::default()},
    }];

    let page1 = PdfPage::new(wid ,hei, page1_contents);
    let pdf_bytes: Vec<u8> = doc.with_pages(vec![page1]).save(&PdfSaveOptions::default());
  
  let jsv=JsValue::from(pdf_bytes);
  let s:Vec<JsValue>=vec![jsv];
  let jsv1=JsValue::from(s);
  let tye=BlobPropertyBag::new();
    tye.set_type("application/pdf");
   let blob=Blob::new_with_u8_array_sequence_and_options(&jsv1,&tye).unwrap();
//let blob=Blob::new_with_u8_array_sequence(&jsv).unwrap();
    let curl=Url::create_object_url_with_blob(&blob).unwrap(); 
       curl
}

 fn main() {
   // console_error_panic_hook::set_once();
  
  // start_app( ) ;
 
}