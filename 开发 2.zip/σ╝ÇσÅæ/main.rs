use printpdf::*;
use std::fs::File;
use std::io::BufWriter;
 
fn main() {
    println!("Hello, world!");

let (doc, page1, layer1) = PdfDocument::new("PDF_Document_title",  Mm(210.0),Mm(297.0), "Layer 1");
  let current_layer = doc.get_page(page1).get_layer(layer1);

// currently, the only reliable file formats are bmp/jpeg/png
// this is an issue of the image library, not a fault of printpdf
let mut image_file = File::open("metest2.png").unwrap();
let image = Image::try_from( image_crate::codecs::png::PngDecoder::new(&mut image_file).unwrap()).unwrap();
image.add_to_layer(current_layer.clone(),  ImageTransform {
      
    //   scale_x:  Some( scale),
      // scale_y:   Some( scale ),
       translate_x: Some(Mm(8.0)),
       translate_y: Some(Mm(8.0)),
       ..Default::default()
   },);
// // layer,
// image.add_to_layer(
//     current_layer.clone(),
//     ImageTransform {
        
//          ..Default::default()
//     },
// );
 
//let pdf_bytes = doc.save_to_bytes().unwrap();

//std::fs::write("foo.pdf", pdf_bytes).unwrap();
  doc.save(&mut BufWriter::new(File::create("test_working.pdf").unwrap())).unwrap(); 

//doc.save(&mut BufWriter::new(File::create("test_working2.pdf").unwrap())).unwrap();

}
